from __future__ import annotations

import hashlib
import json
import logging
from typing import Any

from grimp import _rustgrimp as rust  # type: ignore[attr-defined]
from grimp.application.ports.filesystem import BasicFileSystem
from grimp.application.ports.modulefinder import FoundPackage, ModuleFile
from grimp.domain.valueobjects import DirectImport, Module

from ..application.ports.caching import Cache as AbstractCache
from ..application.ports.caching import CacheMiss

logger = logging.getLogger(__name__)
PrimitiveFormat = dict[str, list[tuple[str, int | None, str]]]


class CacheFileNamer:
    @classmethod
    def make_meta_file_name(cls, found_package: FoundPackage) -> str:
        return f"{found_package.name}.meta.json"

    @classmethod
    def make_data_file_name(
        cls,
        found_packages: set[FoundPackage],
        include_external_packages: bool,
        exclude_type_checking_imports: bool,
    ) -> str:
        identifier = cls.make_data_file_unique_string(
            found_packages, include_external_packages, exclude_type_checking_imports
        )

        bytes_identifier = identifier.encode()
        # Use a hash algorithm with a limited size to avoid cache filenames that are too long
        # the filesystem, which can happen if there are more than a few root packages
        # being analyzed.
        safe_unicode_identifier = hashlib.blake2b(
            bytes_identifier, digest_size=20, usedforsecurity=False
        ).hexdigest()
        return f"{safe_unicode_identifier}.data.json"

    @classmethod
    def make_data_file_unique_string(
        cls,
        found_packages: set[FoundPackage],
        include_external_packages: bool,
        exclude_type_checking_imports: bool,
    ) -> str:
        """
        Construct a unique string that identifies the analysis parameters.

        Doesn't need to be safe to use for a filename.
        """
        package_names = (p.name for p in found_packages)
        csv_packages = ",".join(sorted(package_names))
        include_external_packages_option = ":external" if include_external_packages else ""
        exclude_type_checking_imports_option = (
            ":no_type_checking" if exclude_type_checking_imports else ""
        )
        return (
            csv_packages + include_external_packages_option + exclude_type_checking_imports_option
        )


class Cache(AbstractCache):
    DEFAULT_CACHE_DIR = ".grimp_cache"

    def __init__(self, *args: Any, namer: type[CacheFileNamer], **kwargs: Any) -> None:
        """
        Don't instantiate Cache directly; use Cache.setup().
        """
        super().__init__(*args, **kwargs)
        self._mtime_map: dict[str, float] = {}
        self._data_map: dict[Module, set[DirectImport]] = {}
        self._namer = namer

    @classmethod
    def setup(
        cls,
        file_system: BasicFileSystem,
        found_packages: set[FoundPackage],
        include_external_packages: bool,
        exclude_type_checking_imports: bool = False,
        cache_dir: str | None = None,
        namer: type[CacheFileNamer] = CacheFileNamer,
    ) -> Cache:
        cache = cls(
            file_system=file_system,
            found_packages=found_packages,
            include_external_packages=include_external_packages,
            exclude_type_checking_imports=exclude_type_checking_imports,
            cache_dir=cls.cache_dir_or_default(cache_dir),
            namer=namer,
        )
        cache._build_mtime_map()
        cache._build_data_map()
        assert cache.cache_dir
        return cache

    @classmethod
    def cache_dir_or_default(cls, cache_dir: str | None) -> str:
        return cache_dir or cls.DEFAULT_CACHE_DIR

    def read_imports(self, module_file: ModuleFile) -> set[DirectImport]:
        try:
            cached_mtime = self._mtime_map[module_file.module.name]
        except KeyError as exc:
            raise CacheMiss from exc
        if cached_mtime != module_file.mtime:
            raise CacheMiss

        try:
            return self._data_map[module_file.module]
        except KeyError as exc:
            # While we would expect the module to be in here,
            # there's no point in crashing if, for some reason, it's not.
            raise CacheMiss from exc

    def write(
        self,
        imports_by_module: dict[Module, set[DirectImport]],
    ) -> None:
        self._write_marker_files_if_not_already_there()
        # Write data file.
        data_cache_filename = self.file_system.join(
            self.cache_dir,
            self._namer.make_data_file_name(
                found_packages=self.found_packages,
                include_external_packages=self.include_external_packages,
                exclude_type_checking_imports=self.exclude_type_checking_imports,
            ),
        )
        rust.write_cache_data_map_file(
            filename=data_cache_filename,
            imports_by_module=imports_by_module,
            file_system=self.file_system,
        )

        logger.info(f"Wrote data cache file {data_cache_filename}.")

        # Write meta files.
        for found_package in self.found_packages:
            meta_filename = self.file_system.join(
                self.cache_dir, self._namer.make_meta_file_name(found_package)
            )
            mtime_map = {
                module_file.module.name: module_file.mtime
                for module_file in found_package.module_files
            }
            serialized_meta = json.dumps(mtime_map)
            self.file_system.write(meta_filename, serialized_meta)
            logger.info(f"Wrote meta cache file {meta_filename}.")

    def _build_mtime_map(self) -> None:
        self._mtime_map = self._read_mtime_map_files()

    def _read_mtime_map_files(self) -> dict[str, float]:
        all_mtimes: dict[str, float] = {}
        for found_package in self.found_packages:
            all_mtimes.update(self._read_mtime_map_file(found_package))
        return all_mtimes

    def _read_mtime_map_file(self, found_package: FoundPackage) -> dict[str, float]:
        meta_cache_filename = self.file_system.join(
            self.cache_dir, self._namer.make_meta_file_name(found_package)
        )
        try:
            serialized = self.file_system.read(meta_cache_filename)
        except FileNotFoundError:
            logger.info(f"No cache file: {meta_cache_filename}.")
            return {}
        try:
            deserialized = json.loads(serialized)
        except json.JSONDecodeError:
            logger.warning(f"Could not use corrupt cache file {meta_cache_filename}.")
            return {}

        logger.info(f"Used cache meta file {meta_cache_filename}.")
        return deserialized

    def _build_data_map(self) -> None:
        self._data_map = self._read_data_map_file()

    def _read_data_map_file(self) -> dict[Module, set[DirectImport]]:
        data_cache_filename = self.file_system.join(
            self.cache_dir,
            self._namer.make_data_file_name(
                found_packages=self.found_packages,
                include_external_packages=self.include_external_packages,
                exclude_type_checking_imports=self.exclude_type_checking_imports,
            ),
        )
        try:
            imports_by_module = rust.read_cache_data_map_file(
                data_cache_filename, self.file_system
            )
        except FileNotFoundError:
            logger.info(f"No cache file: {data_cache_filename}.")
            return {}
        except rust.CorruptCache:
            logger.warning(f"Could not use corrupt cache file {data_cache_filename}.")
            return {}

        logger.info(f"Used cache data file {data_cache_filename}.")
        return imports_by_module

    def _build_data_cache_filename(self, found_package: FoundPackage) -> str:
        return self.file_system.join(self.cache_dir, f"{found_package.name}.data.json")

    def _write_marker_files_if_not_already_there(self) -> None:
        marker_files_info = (
            (".gitignore", "# Automatically created by Grimp.\n*"),
            (
                "CACHEDIR.TAG",
                (
                    "Signature: 8a477f597d28d172789f06886806bc55\n"
                    "# This file is a cache directory tag automatically created by Grimp.\n"
                    "# For information about cache directory tags see https://bford.info/cachedir/"
                ),
            ),
        )

        for filename, contents in marker_files_info:
            full_filename = self.file_system.join(self.cache_dir, filename)
            if not self.file_system.exists(full_filename):
                self.file_system.write(full_filename, contents)
